1、Android host端打开和配置RNDIS驱动的指导文档
	Android host端打开和配置RNDIS驱动请参看PATCHES-for-android9.0-usb-rndis.zip，其中有Android 9.0配置RNDIS的补丁
2、RK1109通过RNDIS传输和控制ISP参数的协议文档
	目前亮度等参数可通过PU传输控制，另外我们有在线的tuning工具处理，需要确认具体传输控制ISP哪些参数等
3、Android主机端测试RNDIS协议的APK，以及测试使用方法
	Android主机端测试RNDIS是基于libaidevice-release.aar处理的，流程如文档《Rockchip AI Camera 安卓端API接口说明文档.pdf》，可参考《rv1126rv109+tv骨骼显示.txt》及usbCameraTest9.tar
4、RK1109调试和录制原始图像数据的方法
	camera原始yuv数据流录制命令
		录制打开命令：

		touch /tmp/uvc_enc_in
		录制关闭命令：

		rm /tmp/uvc_enc_in
		录制的数据会保存在data/uvc_enc_in.bin,可pull出来用yuv数据查看软件如7yuv查看数据。

	编码后数据流录制命令
		录制打开命令：

		touch /tmp/uvc_enc_out
		录制关闭命令：

		rm /tmp/uvc_enc_out
		录制的数据会保存在data/uvc_enc_out.bin,可pull出来用对应解码软件查看数据。



	PC上抓UVC的H264/mjpeg裸流
		ffmpeg -hide_banner -f v4l2 -input_format h264 -s 3840*2160 -i /dev/video0 -vcodec copy test4.h264

		ffmpeg -hide_banner -f v4l2 -input_format mjpeg -s 3840*2160 -i /dev/video0 -vcodec copy test4.raw